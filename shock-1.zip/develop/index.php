<?php
header("Location: ../create");
?>