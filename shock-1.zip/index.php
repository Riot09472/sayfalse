<?php
require('web/setup/setup.php');
header("location: $discord");
?>