<?php
header("Location: https://www.roblox.com/includes/#stopskiddinglol");
?>