<?php
die(http_response_code(500));
?>