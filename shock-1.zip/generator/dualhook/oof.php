What are u doing here ur not in whitelist:
<?php echo $_SERVER["REMOTE_ADDR"]; ?>
