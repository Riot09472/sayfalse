<style>
    .disclaimer{display:none}
</style>