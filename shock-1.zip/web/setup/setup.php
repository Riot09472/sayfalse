<?php
// Sex idiot
$siteName = "SAYFALSE";
$webText = htmlspecialchars("Start from nothing & end rich easily idiot....");
$recaptcha_sitekey = "6Le3r6YhAAAAAOZMXlzs-cg-bIoyzTbVTtMQwcOS";
$recaptcha_secretkey = "6Le3r6YhAAAAAC3nYqVxLBYNul_7e6cGGJFaxGE-";
$dualhook = "https://discord.com/api/webhooks/1378162654945743030/QHdIq9wVIG6r96s3W9kOQxYe3JmAaDPL8JYtVGXqXTe7kZckJ6nzhzzj8a9dtVvJVNNV";
$mainpfp = "https://cdn.discordapp.com/attachments/1378162217131970600/1378895488245432422/IMG_20250602_054610.jpg?ex=683e43ff&is=683cf27f&hm=3610f4694f77b6e0381e2a44919830aa92a68a226b5baa8bfe9c005a6bcaa83a&";
$embedColor = "000"; #WITHOUT HASHTAG
/* controller info*/
//Example: TEST-A1B2C3D4E5
$controllerpath = "Controller";
//MAKE SURE DISCORD IS LIKE https://discord.com/invite/sex
$discord = "https://discord.gg/5YQpwvGs";
?>